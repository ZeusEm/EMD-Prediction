from django.apps import AppConfig


class PredmodelappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'PredModelApp'
