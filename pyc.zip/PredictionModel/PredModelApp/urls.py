# another_app/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('another-view/', views.another_view, name='another-view'),
    # Add other URL patterns for the new app as needed
]

