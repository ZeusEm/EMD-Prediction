import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from dash import Dash, html, dcc, callback, Input, Output
import plotly.express as px

# Load your Excel data
file_path = "AI_TABLE.xls"
df = pd.read_excel(file_path)

df = df.head(400)

df.fillna("unassigned", inplace=True) 

# Assume you want to predict the "target_column" based on the "feature_column" and "categorical_columns"
feature_column = "JOBDETAIL"
categorical_columns = ["STR_SHIPNAME", "STR_REFIT_CODE", "FLG_OFFLOADED"]
target_column = "EMD"

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    df[[feature_column] + categorical_columns], df[target_column], test_size=0.2, random_state=42
)

# Use CountVectorizer to convert text data to numeric format
text_vectorizer = CountVectorizer()
categorical_encoder = OneHotEncoder()

# Combine text and categorical features
preprocessor = ColumnTransformer(
    transformers=[
        ('text', text_vectorizer, feature_column),
        ('categorical', categorical_encoder, categorical_columns)
    ],
    remainder='passthrough'
)

# Create a pipeline with the preprocessor and the RandomForestRegressor
model = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('regressor', RandomForestRegressor())
])

# Train the model
model.fit(X_train, y_train)

# Create Dash app
app = Dash(__name__)

# Layout of the app
app.layout = html.Div([
    dcc.Input(id='search-input', type='text', placeholder='Enter search term'),
    dcc.Dropdown(
        id='categorical-dropdown-shipname',
        options=[{'label': col, 'value': col} for col in df["STR_SHIPNAME"].unique()],
        value=df["STR_SHIPNAME"].unique()[0],
        placeholder='Select a ship name'
    ),
    dcc.Dropdown(
        id='categorical-dropdown-refitcode',
        options=[{'label': col, 'value': col} for col in df["STR_REFIT_CODE"].unique()],
        value=df["STR_REFIT_CODE"].unique()[0],
        placeholder='Select a refit code'
    ),
    dcc.Dropdown(
        id='categorical-dropdown-offloaded',
        options=[{'label': col, 'value': col} for col in df["FLG_OFFLOADED"].unique()],
        value=df["FLG_OFFLOADED"].unique()[0],
        placeholder='Select offloaded status'
    ),
    dcc.Graph(id='prediction-plot'),
])

# Callback to update the graph based on the search input and dropdown selections
@app.callback(
    Output('prediction-plot', 'figure'),
    [Input('search-input', 'value'),
     Input('categorical-dropdown-shipname', 'value'),
     Input('categorical-dropdown-refitcode', 'value'),
     Input('categorical-dropdown-offloaded', 'value')]
)
def update_graph(search_term, selected_shipname, selected_refitcode, selected_offloaded):
    if search_term and selected_shipname and selected_refitcode and selected_offloaded:
        # Create a DataFrame for the search term and the selected categorical values
        input_data = pd.DataFrame({
            'JOBDETAIL': [search_term],
            'STR_SHIPNAME': [selected_shipname],
            'STR_REFIT_CODE': [selected_refitcode],
            'FLG_OFFLOADED': [selected_offloaded]
        })

        # Make predictions for the transformed input data
        prediction = model.predict(input_data)

        # Create a new DataFrame with the search term, actual, and predicted values
        result_df = pd.DataFrame({
            'Data': [search_term],
            'Ship Name': [selected_shipname],
            'Refit Code': [selected_refitcode],
            'Offloaded Status': [selected_offloaded],
            'Prediction': [prediction[0]]
        })

        # Create a scatter plot using Plotly Express
        fig = px.scatter(
            result_df, x='Data', y='Prediction',
            labels={'Prediction': 'Predicted Value'},
            hover_data=['Ship Name', 'Refit Code', 'Offloaded Status'],
            title=f'Actual vs Predicted for {search_term}'
        )
        return fig
    else:
        # If no search term or categorical value is provided, return an empty graph
        return px.scatter()

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
