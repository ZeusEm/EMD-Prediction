import pandas as pd
import numpy as np

# Set a random seed for reproducibility
np.random.seed(42)

# Generate random health data
data = {
    'Age': np.random.randint(20, 70, size=1000),
    'Weight': np.random.uniform(50, 100, size=1000),
    'Height': np.random.uniform(150, 200, size=1000),
    'BloodPressure': np.random.randint(90, 140, size=1000),
    'Target': np.random.uniform(70, 100, size=1000)
}

health_data_generated = pd.DataFrame(data)

# Save the generated data to an Excel file
health_data_generated.to_excel('health_data_generated.xlsx', index=False)
