import pandas as pd
import numpy as np
import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
import scipy
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV

# Load the data into a pandas DataFrame
data = pd.read_excel('AI_TABLE.xls')

# Crop the DataFrame to the first 5999 rows
data = data.head(5999)

# Data Preprocessing
# Handle missing values if needed
data.fillna(0, inplace=True)  # Replace missing values with 0 for simplicity

# Encode categorical variables (one-hot encoding)
categorical_columns = ['STR_SHIPNAME', 'STR_REFIT_CODE', 'FLG_OFFLOADED', 'EQUIPMENT_NAME', 'WI_QC_REMARK']
data = pd.get_dummies(data, columns=categorical_columns)

# Module 4: Text Data Preprocessing
text_features = ['JOBHEAD', 'DEFECT_DESC', 'JOBSUM', 'JOBDETAIL']  # Update the column names based on your data

# Create a DataFrame for text features
text_data_df = data[text_features].apply(lambda x: ' '.join(map(str, x)), axis=1)

# Feature Engineering for Text Data
tfidf_vectorizer = TfidfVectorizer(max_features=5000, stop_words='english')
text_features_transformed = tfidf_vectorizer.fit_transform(text_data_df)

# Create a DataFrame for numeric features
numeric_columns = data.drop(columns=['EMD', 'JOBNO', 'WONO'] + text_features)  # Remove text columns

# Convert all columns to strings
numeric_columns = numeric_columns.astype(str)

# Replace non-numeric values with placeholders (e.g., 'True' and 'False' with '0')
numeric_columns = numeric_columns.applymap(lambda x: '0' if x.lower() in ('true', 'false') else x)

# Convert columns to float
for column in numeric_columns.columns:
    numeric_columns[column] = pd.to_numeric(numeric_columns[column], errors='coerce')
    numeric_columns[column] = numeric_columns[column].fillna(0).astype(float)

# Combine text features with numeric features using a sparse matrix
X = scipy.sparse.hstack((text_features_transformed, numeric_columns.values), format='csr')

# Target variable
y = data['EMD']

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model Selection
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the layout of the app
app.layout = html.Div([
    html.H1("EMD Prediction App"),
    
    html.Label("Enter job details:"),
    dcc.Textarea(id='job_details', value='', style={'width': '100%'}),
    
    html.Button('Predict EMD', id='predict_button', n_clicks=0),
    
    html.Div(id='prediction_output'),
])

# Define callback to update prediction_output
@app.callback(
    Output('prediction_output', 'children'),
    [Input('predict_button', 'n_clicks')],
    [dash.dependencies.State('job_details', 'value')]
)
def update_output(n_clicks, job_details):
    # Preprocess input data
    input_data = pd.DataFrame({'JOBDETAIL': [job_details]})
    input_text_data = input_data['JOBDETAIL'].apply(lambda x: ' '.join(map(str, x)))
    input_text_transformed = tfidf_vectorizer.transform(input_text_data)

    input_numeric_data = input_data.drop(columns=['JOBDETAIL']).astype(str)
    input_numeric_data = input_numeric_data.applymap(lambda x: '0' if x.lower() in ('true', 'false') else x)
    input_numeric_data = input_numeric_data.applymap(lambda x: float(x))

    # Combine text features with numeric features using a sparse matrix
    input_X = scipy.sparse.hstack((input_text_transformed, input_numeric_data.values), format='csr')

    # Make prediction
    prediction = model.predict(input_X)

    return f'Predicted EMD: {prediction[0]:.3f}'

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
