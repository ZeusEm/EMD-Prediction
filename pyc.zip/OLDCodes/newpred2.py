# Step 1: Data Preprocessing
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_squared_error

# Load data from Excel file
data = pd.read_excel("AI_TABLE.xls")

# Step 1.1: Identify and Handle Non-Numeric Values
numeric_cols = ['JOBNO', 'ITEMNO', 'WONO', 'JOBSUM', 'CNO', 'EMD']

# Convert non-numeric values to NaN and drop rows with NaN values
data[numeric_cols] = data[numeric_cols].apply(pd.to_numeric, errors='coerce')
data_cleaned = data.dropna(subset=numeric_cols)

# Step 2: Feature Engineering
# Extract features and target variable
X_text = data_cleaned[['JOBHEAD', 'DEFECT_DESC', 'JOBSUM', 'JOBDETAIL', 'WI_QC_REMARK']]
X_numeric = data_cleaned[['JOBNO', 'ITEMNO', 'WONO', 'JOBSUM', 'CNO']]

# Step 2.1: Text Vectorization
text_features = ['JOBHEAD', 'DEFECT_DESC', 'JOBSUM', 'JOBDETAIL', 'WI_QC_REMARK']
text_transformer = Pipeline(steps=[
    ('tfidf', TfidfVectorizer(stop_words='english', max_features=5000))  # You can adjust max_features
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', 'passthrough', X_numeric.columns),
        ('text', text_transformer, text_features)
    ])



# Combine text and numeric features
X_processed = pd.DataFrame(preprocessor.fit_transform(data_cleaned), columns=X_numeric.columns.tolist() + text_features)
X = pd.concat([X_numeric, X_processed.drop(X_numeric.columns, axis=1)], axis=1)
y = data_cleaned['EMD']


# Combine text and numeric features separately
X_combined = pd.concat([X_numeric, X_processed.drop(X_numeric.columns, axis=1)], axis=1)


# Step 3: Model Training
# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Choose a model and train it
model = RandomForestRegressor(random_state=42)
model.fit(X_train, y_train)

# Step 4: Model Evaluation
# Evaluate the model on the testing set
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
print(f"Mean Squared Error: {mse}")

# Step 5: Dash Web Application
import dash
from dash import dcc, html
from dash.dependencies import Input, Output

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the app layout
app.layout = html.Div([
    dcc.Input(id='jobno-input', type='text', placeholder='Enter JOBNO'),
    dcc.Input(id='itemno-input', type='text', placeholder='Enter ITEMNO'),
    dcc.Input(id='wono-input', type='text', placeholder='Enter WONO'),
    dcc.Input(id='jobsum-input', type='text', placeholder='Enter JOBSUM'),
    dcc.Input(id='cno-input', type='text', placeholder='Enter CNO'),
    dcc.Input(id='jobhead-input', type='text', placeholder='Enter JOBHEAD'),
    dcc.Input(id='defect-desc-input', type='text', placeholder='Enter DEFECT_DESC'),
    dcc.Input(id='jobdetail-input', type='text', placeholder='Enter JOBDETAIL'),
    dcc.Input(id='wi-qc-remark-input', type='text', placeholder='Enter WI_QC_REMARK'),
    html.Div(id='prediction-output')
])

# Define callback to update output based on user input
@app.callback(
    Output('prediction-output', 'children'),
    [Input('jobno-input', 'value'),
     Input('itemno-input', 'value'),
     Input('wono-input', 'value'),
     Input('jobsum-input', 'value'),
     Input('cno-input', 'value'),
     Input('jobhead-input', 'value'),
     Input('defect-desc-input', 'value'),
     Input('jobdetail-input', 'value'),
     Input('wi-qc-remark-input', 'value')])
def update_prediction(jobno, itemno, wono, jobsum, cno, jobhead, defect_desc, jobdetail, wi_qc_remark):
    # Use the trained model to make predictions
    input_data = [[pd.to_numeric(jobno, errors='coerce'),
                   pd.to_numeric(itemno, errors='coerce'),
                   pd.to_numeric(wono, errors='coerce'),
                   pd.to_numeric(jobsum, errors='coerce'),
                   pd.to_numeric(cno, errors='coerce'),
                   jobhead,
                   defect_desc,
                   jobdetail,
                   wi_qc_remark]]

    prediction = model.predict(preprocessor.transform(pd.DataFrame(input_data, columns=X_combined.columns)))[0]
    return f'Predicted EMD: {prediction}'


# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
