import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
import scipy
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV
import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output

# Load the data into a pandas DataFrame
data = pd.read_excel('AI_TABLE.xls')



# Crop the DataFrame to the first 5999 rows
data = data.head(5999)

# Data Preprocessing
# Handle missing values if needed
data.fillna(0, inplace=True)  # Replace missing values with 0 for simplicity

# Encode categorical variables (one-hot encoding)
categorical_columns = ['STR_SHIPNAME', 'STR_REFIT_CODE', 'FLG_OFFLOADED', 'EQUIPMENT_NAME', 'WI_QC_REMARK'] 
data = pd.get_dummies(data, columns=categorical_columns)

# Module 4: Text Data Preprocessing
text_features = ['JOBHEAD', 'DEFECT_DESC', 'JOBSUM', 'JOBDETAIL']  # Update the column names based on your data

# Create a DataFrame for text features
text_data_df = data[text_features].apply(lambda x: ' '.join(map(str, x)), axis=1)

# Feature Engineering for Text Data
tfidf_vectorizer = TfidfVectorizer(max_features=5000, stop_words='english')
text_features_transformed = tfidf_vectorizer.fit_transform(text_data_df)

# Create a DataFrame for numeric features
numeric_columns = data.drop(columns=['EMD', 'JOBNO', 'WONO'] + text_features)  # Remove text columns

# Convert all columns to strings
numeric_columns = numeric_columns.astype(str)

# Replace non-numeric values with placeholders (e.g., 'True' and 'False' with '0')
numeric_columns = numeric_columns.applymap(lambda x: '0' if x.lower() in ('true', 'false') else x)

# Convert columns to float
for column in numeric_columns.columns:
    numeric_columns[column] = pd.to_numeric(numeric_columns[column], errors='coerce')
    numeric_columns[column] = numeric_columns[column].fillna(0).astype(float)

# Combine text features with numeric features using a sparse matrix
X = scipy.sparse.hstack((text_features_transformed, numeric_columns.values), format='csr')

# Target variable
y = data['EMD']

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model Selection
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# TF-IDF vectorizer used during training
tfidf_vectorizer = TfidfVectorizer(max_features=5000, stop_words='english')
text_features_transformed = tfidf_vectorizer.fit_transform(text_data_df)

# Train-Test Split
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# # Model Selection
# model = RandomForestRegressor(n_estimators=100, random_state=42)
# model.fit(X_train, y_train)

# Initialize the Dash web application
app = dash.Dash(__name__)

# Define the layout of the dashboard
app.layout = html.Div(children=[
    html.H1(children='EMD Prediction Dashboard'),

    html.Div(children='''
        Predicting EMD values based on input features.
    '''),

    # Input components for user to enter data
    html.Label('Enter Job Information:'),
    dcc.Input(id='jobhead-input', type='text', placeholder='Job Head'),
    dcc.Input(id='defect-desc-input', type='text', placeholder='Defect Description'),
    dcc.Input(id='jobsum-input', type='text', placeholder='Job Summary'),
    dcc.Input(id='jobdetail-input', type='text', placeholder='Job Detail'),

    # Output component to display prediction
    html.Br(),
    html.Div(id='output-prediction'),

])

# # Define callback to update the prediction based on user input
# # @app.callback(
# #     Output('output-prediction', 'children'),
# #     [Input('jobhead-input', 'value'),
# #      Input('defect-desc-input', 'value'),
# #      Input('jobsum-input', 'value'),
# #      Input('jobdetail-input', 'value')]
# # )
# # def update_prediction(jobhead, defect_desc, jobsum, jobdetail):
# #     # Make a prediction using the trained model
# #     input_data = pd.DataFrame([[jobhead, defect_desc, jobsum, jobdetail]])
# #     input_data_transformed = tfidf_vectorizer.transform(input_data.apply(lambda x: ' '.join(map(str, x)), axis=1))
# #     numeric_input_data = input_data.drop(columns=[0]).astype(float)
# #     combined_input = scipy.sparse.hstack((input_data_transformed, numeric_input_data.values), format='csr')
    
# #     prediction = model.predict(combined_input)[0]

# #     return f'Predicted EMD: {prediction:.3f}'

# @app.callback(
#     Output('output-prediction', 'children'),
#     [Input('jobhead-input', 'value'),
#      Input('defect-desc-input', 'value'),
#      Input('jobsum-input', 'value'),
#      Input('jobdetail-input', 'value')]
# )
# def update_prediction(jobhead, defect_desc, jobsum, jobdetail):
#     # Make sure to match the text features used during training
#     input_data = pd.DataFrame([[jobhead, defect_desc, jobsum, jobdetail]], columns=text_features)
    
#     # Feature Engineering for Text Data
#     text_data_df = input_data.apply(lambda x: ' '.join(map(str, x)), axis=1)
#     text_data_transformed = tfidf_vectorizer.transform(text_data_df)

#     # Create a DataFrame for numeric features
#     numeric_data = input_data.drop(text_features, axis=1).astype(float)

#     # Combine text features with numeric features using a sparse matrix
#     input_combined = scipy.sparse.hstack((text_data_transformed, numeric_data.values), format='csr')
    
#     # Make a prediction using the trained model
#     prediction = model.predict(input_combined)[0]

#     return f'Predicted EMD: {prediction:.3f}'



# ... (rest of the code)

# Initialize the Dash web application
#app = dash.Dash(__name__)

# ... (rest of the code)

# Define callback to update the prediction based on user input
@app.callback(
    Output('output-prediction', 'children'),
    [Input('jobhead-input', 'value'),
     Input('defect-desc-input', 'value'),
     Input('jobsum-input', 'value'),
     Input('jobdetail-input', 'value')]
)
def update_prediction(jobhead, defect_desc, jobsum, jobdetail):
    # Make sure to match the text features used during training
    input_data = pd.DataFrame([[jobhead, defect_desc, jobsum, jobdetail]], columns=text_features)
    
    # Feature Engineering for Text Data
    text_data_df = input_data.apply(lambda x: ' '.join(map(str, x)), axis=1)
    text_data_transformed = tfidf_vectorizer.transform(text_data_df)

    # Check if the number of features matches the model's expectation
    if text_data_transformed.shape[1] != text_features_transformed.shape[1]:
        raise ValueError("Number of features in input data doesn't match the model's expectation.")

    # Create a DataFrame for numeric features
    numeric_data = input_data.drop(text_features, axis=1).astype(float)

    # Combine text features with numeric features using a sparse matrix
    input_combined = scipy.sparse.hstack((text_data_transformed, numeric_data.values), format='csr')
    
    # Make a prediction using the trained model
    prediction = model.predict(input_combined)[0]

    return f'Predicted EMD: {prediction:.3f}'


# Run the Dash web application
if __name__ == '__main__':
    app.run_server(debug=True)