# Step 1: Data Preprocessing
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error

# Load data from Excel file
data = pd.read_excel("AI_TABLE.xls")

# Step 1.1: Identify and Handle Non-Numeric Values
numeric_cols = ['JOBNO', 'ITEMNO', 'WONO', 'JOBSUM', 'CNO', 'EMD']

# Convert non-numeric values to NaN and drop rows with NaN values
data[numeric_cols] = data[numeric_cols].apply(pd.to_numeric, errors='coerce')
data_cleaned = data.dropna(subset=numeric_cols)

# Step 2: Feature Engineering
# Extract features and target variable
X = data_cleaned[['JOBNO', 'ITEMNO', 'WONO', 'JOBSUM', 'CNO']]
y = data_cleaned['EMD']

# Step 3: Model Training
# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Choose a model and train it
model = RandomForestRegressor(random_state=42)
model.fit(X_train, y_train)

# Step 4: Model Evaluation
# Evaluate the model on the testing set
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
print(f"Mean Squared Error: {mse}")

# Step 5: Dash Web Application
import dash
from dash import dcc, html
from dash.dependencies import Input, Output

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the app layout
app.layout = html.Div([
    dcc.Input(id='jobno-input', type='text', placeholder='Enter JOBNO'),
    dcc.Input(id='itemno-input', type='text', placeholder='Enter ITEMNO'),
    dcc.Input(id='wono-input', type='text', placeholder='Enter WONO'),
    dcc.Input(id='jobsum-input', type='text', placeholder='Enter JOBSUM'),
    dcc.Input(id='cno-input', type='text', placeholder='Enter CNO'),
    html.Div(id='prediction-output')
])

# Define callback to update output based on user input
@app.callback(
    Output('prediction-output', 'children'),
    [Input('jobno-input', 'value'),
     Input('itemno-input', 'value'),
     Input('wono-input', 'value'),
     Input('jobsum-input', 'value'),
     Input('cno-input', 'value')])
def update_prediction(jobno, itemno, wono, jobsum, cno):
    # Use the trained model to make predictions
    input_data = [[pd.to_numeric(jobno, errors='coerce'),
                   pd.to_numeric(itemno, errors='coerce'),
                   pd.to_numeric(wono, errors='coerce'),
                   pd.to_numeric(jobsum, errors='coerce'),
                   pd.to_numeric(cno, errors='coerce')]]

    prediction = model.predict(input_data)[0]
    return f'Predicted EMD: {prediction}'

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
