import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_extraction.text import CountVectorizer
from dash import Dash, html, dcc, callback, Input, Output
import plotly.express as px

# Load your Excel data
file_path = "AI_TABLE.xls"
df = pd.read_excel(file_path)

df = df.head(20)

df.fillna(0, inplace=True) 
# Assume you want to predict the "target_column" based on the "feature_column"
feature_column = "JOBDETAIL"
target_column = "EMD"

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    df[feature_column], df[target_column], test_size=0.2, random_state=42
)

# Use CountVectorizer to convert text data to numeric format
vectorizer = CountVectorizer()
X_train_numeric = vectorizer.fit_transform(X_train)
X_test_numeric = vectorizer.transform(X_test)

# Train a simple RandomForestRegressor model
model = RandomForestRegressor()
model.fit(X_train_numeric, y_train)

# Create Dash app
app = Dash(__name__)

# Layout of the app
app.layout = html.Div([
    dcc.Input(id='search-input', type='text', placeholder='Enter search term'),
    dcc.Graph(id='prediction-plot'),
])

# Callback to update the graph based on the search input
@app.callback(
    Output('prediction-plot', 'figure'),
    [Input('search-input', 'value')]
)
def update_graph(search_term):
    if search_term:
        # Use the same vectorizer to transform the search term
        search_term_numeric = vectorizer.transform([search_term])
        
        # Make predictions for the transformed search term
        prediction = model.predict(search_term_numeric)
        
        # Create a new DataFrame with the search term and prediction
        result_df = pd.DataFrame({
            'Data': [search_term],
            'Prediction': [prediction[0]]
        })
        
        # Create a scatter plot using Plotly Express
        fig = px.scatter(result_df, x='Data', y='Prediction', labels={'Prediction': 'Predicted Value'})
        return fig
    else:
        # If no search term is provided, return an empty graph
        return px.scatter()

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
