import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import dash
import dash_core_components as dcc
from dash import html
from dash.dependencies import Input, Output

# Load health data from Excel file
#health_data = pd.read_excel("health_data_generated.xlsx")


excel_file_path = "health_data_generated.xlsx"
xl = pd.ExcelFile(excel_file_path)
sheet_names = xl.sheet_names

# Concatenate data from all worksheets into a single DataFrame
health_data = pd.concat([xl.parse(sheet_name) for sheet_name in sheet_names], ignore_index=True)





# Assume your data has columns like 'Age', 'Weight', 'Height', 'BloodPressure', 'Target'
# Replace 'Target' with the actual column name you want to predict

# Features (X) and target variable (y)
X = health_data[['Age', 'Weight', 'Height', 'BloodPressure']]
y = health_data['Target']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a simple linear regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Initialize the Dash web application
app = dash.Dash(__name__)

# Define the layout of the dashboard
app.layout = html.Div(children=[
    html.H1(children='Health Data Dashboard'),

    html.Div(children='''
        Predicting health outcomes based on input features.
    '''),

    # Input components for user to enter data
    html.Label('Enter Patient Information:'),
    dcc.Input(id='age-input', type='number', placeholder='Age'),
    dcc.Input(id='weight-input', type='number', placeholder='Weight'),
    dcc.Input(id='height-input', type='number', placeholder='Height'),
    dcc.Input(id='bp-input', type='number', placeholder='Blood Pressure'),

    # Output component to display prediction
    html.Br(),
    html.Div(id='output-prediction'),

])

# Define callback to update the prediction based on user input
@app.callback(
    Output('output-prediction', 'children'),
    [Input('age-input', 'value'),
     Input('weight-input', 'value'),
     Input('height-input', 'value'),
     Input('bp-input', 'value')]
)
def update_prediction(age, weight, height, bp):
    # Make a prediction using the trained model
    input_data = pd.DataFrame([[age, weight, height, bp]], columns=['Age', 'Weight', 'Height', 'BloodPressure'])
    prediction = model.predict(input_data)[0]

    return f'Predicted Outcome: {prediction:.2f}'

# Run the Dash web application
if __name__ == '__main__':
    app.run_server(debug=True)