import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from flask import Flask, render_template, request
import plotly.express as px
import plotly.graph_objs as go

# Load your Excel data
file_path = "AI_TABLE.xls"
df = pd.read_excel(file_path)

df = df.head(400)
df.fillna("unassigned", inplace=True) 

# Assume you want to predict the "target_column" based on the "feature_columns" and "categorical_columns"
text_feature_columns = ["DEFECT_DESC", "JOBDETAIL", "JOBSUM", "JOBHEAD"]
categorical_columns = ["STR_SHIPNAME", "STR_REFIT_CODE", "FLG_OFFLOADED", "EQUIPMENT_NAME", "WI_QC_REMARK"]
target_column = "EMD"

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    df[text_feature_columns + categorical_columns], df[target_column], test_size=0.2, random_state=42
)

# Use CountVectorizer to convert text data to numeric format for text columns
text_vectorizer = ColumnTransformer(
    transformers=[
        ('defect_text', CountVectorizer(), 'DEFECT_DESC'),
        ('jobdetail_text', CountVectorizer(), 'JOBDETAIL'),
        ('jobsum_text', CountVectorizer(), 'JOBSUM'),
        ('jobhead_text', CountVectorizer(), 'JOBHEAD')
    ],
    remainder='passthrough'
)

categorical_encoder = OneHotEncoder()

# Combine text and categorical features
preprocessor = ColumnTransformer(
    transformers=[
        ('text', text_vectorizer, text_feature_columns),
        ('categorical', categorical_encoder, categorical_columns)
    ],
    remainder='passthrough'
)

# Create a pipeline with the preprocessor and the RandomForestRegressor
model = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('regressor', RandomForestRegressor())
])

# Train the model
model.fit(X_train, y_train)

# Create Flask app
app = Flask(__name__)

# Route for the main page
@app.route('/')
def index():
    return render_template('index.html')

# Route for handling form submission
@app.route('/predict', methods=['POST'])
def predict():
    # Retrieve form data
    defect_desc = request.form['defect_desc']
    job_detail = request.form['job_detail']
    job_sum = request.form['job_sum']
    job_head = request.form['job_head']
    selected_shipname = request.form['selected_shipname']
    selected_refitcode = request.form['selected_refitcode']
    selected_offloaded = request.form['selected_offloaded']
    selected_equipment = request.form['selected_equipment']
    selected_qcremark = request.form['selected_qcremark']

    # Create a DataFrame for the input features
    input_data = pd.DataFrame({
        'DEFECT_DESC': [defect_desc],
        'JOBDETAIL': [job_detail],
        'JOBSUM': [job_sum],
        'JOBHEAD': [job_head],
        'STR_SHIPNAME': [selected_shipname],
        'STR_REFIT_CODE': [selected_refitcode],
        'FLG_OFFLOADED': [selected_offloaded],
        'EQUIPMENT_NAME': [selected_equipment],
        'WI_QC_REMARK': [selected_qcremark]
    })

    # Make predictions for the transformed input data
    prediction = model.predict(input_data)

    # Create a new DataFrame with the input values and predicted values
    result_df = pd.DataFrame({
        'Defect Description': [defect_desc],
        'Job Detail': [job_detail],
        'Job Summary': [job_sum],
        'Job Head': [job_head],
        'Ship Name': [selected_shipname],
        'Refit Code': [selected_refitcode],
        'Offloaded Status': [selected_offloaded],
        'Equipment Name': [selected_equipment],
        'QC Remark': [selected_qcremark],
        'Prediction': [prediction[0]]
    })

    # Create a scatter plot using Plotly Express
    scatter_fig = px.scatter(
        result_df, x='Job Detail', y='Prediction',
        labels={'Prediction': 'Predicted Value'},
        hover_data=['Defect Description', 'Job Summary', 'Job Head', 'Ship Name', 'Refit Code', 'Offloaded Status', 'Equipment Name', 'QC Remark'],
        title=f'Actual vs Predicted for {job_detail}'
    )

    # Generate a normal distribution curve for target column "EMD"
    plt.figure(figsize=(10, 6))
    sns.histplot(df[target_column], kde=True, stat='density', color='blue', bins=30, label='Actual Data')
    sns.kdeplot(df[target_column], color='blue')
    plt.axvline(x=prediction[0], color='red', linestyle='--', label='Predicted Value')
    plt.title('Normal Distribution Curve for EMD with Predicted Value')
    plt.xlabel('EMD')
    plt.ylabel('Density')
    plt.xlim(0, 1200)  # Limit x-axis to positive values between 0 and 1200
    plt.legend()

    # Save the Matplotlib figure to a file
    plt.savefig('static/normal_distribution.png')
    plt.close()

    return render_template('result.html', scatter_plot=scatter_fig.to_html())

if __name__ == '__main__':
    app.run(debug=True)
